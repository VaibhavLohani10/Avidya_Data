create function regexp_split_to_table(string citext, pattern citext) returns SETOF text
    immutable
    strict
    parallel safe
    language sql
RETURN regexp_split_to_table((string)::text, (pattern)::text, 'i'::text);

alter function regexp_split_to_table(citext, citext) owner to postgres;


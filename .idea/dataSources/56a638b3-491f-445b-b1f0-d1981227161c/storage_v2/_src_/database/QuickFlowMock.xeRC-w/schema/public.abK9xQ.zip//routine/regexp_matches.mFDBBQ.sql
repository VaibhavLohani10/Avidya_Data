create function regexp_matches(string citext, pattern citext) returns SETOF text[]
    immutable
    strict
    parallel safe
    rows 1
    language sql
RETURN regexp_matches((string)::text, (pattern)::text, 'i'::text);

alter function regexp_matches(citext, citext) owner to postgres;


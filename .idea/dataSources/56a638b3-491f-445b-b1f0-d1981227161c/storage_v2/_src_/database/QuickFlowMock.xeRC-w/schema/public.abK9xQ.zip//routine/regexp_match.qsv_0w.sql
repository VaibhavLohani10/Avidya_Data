create function regexp_match(string citext, pattern citext) returns text[]
    immutable
    strict
    parallel safe
    language sql
RETURN regexp_match((string)::text, (pattern)::text, 'i'::text);

alter function regexp_match(citext, citext) owner to postgres;


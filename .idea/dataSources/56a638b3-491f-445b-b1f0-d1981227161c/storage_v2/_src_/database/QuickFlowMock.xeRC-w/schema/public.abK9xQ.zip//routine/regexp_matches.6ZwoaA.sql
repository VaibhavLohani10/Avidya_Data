create function regexp_matches(string citext, pattern citext, flags text) returns SETOF text[]
    immutable
    strict
    parallel safe
    rows 10
    language sql
RETURN regexp_matches((string)::text, (pattern)::text, CASE WHEN (strpos(flags, 'c'::text) = 0) THEN (flags || 'i'::text) ELSE flags END);

alter function regexp_matches(citext, citext, text) owner to postgres;


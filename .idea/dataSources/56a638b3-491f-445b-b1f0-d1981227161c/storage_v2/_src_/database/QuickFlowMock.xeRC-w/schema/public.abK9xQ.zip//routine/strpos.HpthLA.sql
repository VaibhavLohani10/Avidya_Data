create function strpos(citext, citext) returns integer
    immutable
    strict
    parallel safe
    language sql
RETURN strpos(lower(($1)::text), lower(($2)::text));

alter function strpos(citext, citext) owner to postgres;

